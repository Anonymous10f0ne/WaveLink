# WaveLink Architecture
Browser -> Cloudflare/edge -> Vercel -> API -> Supabase/Postgres (planned)
                                             -> private media storage (planned)
                                             -> AI provider server-side (planned)
                                             -> payment provider abstraction (planned)

Security rule: secrets never live in index.html or browser JavaScript.
