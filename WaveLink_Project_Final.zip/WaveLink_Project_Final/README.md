# WaveLink Production Foundation

Start with `index.html`. This preserves the WaveLink direction instead of starting over: branded landing page, discovery/The Wave, Rising Wave, AI entry point, Trust & Safety, waitlist, animated surf visual, production headers, API boundary, and CI.

## Deploy
1. Upload the project contents to the existing WaveLink GitHub repository.
2. Commit to `main`.
3. Let the existing Vercel project deploy.
4. Test the production URL on desktop and mobile.

## Not yet production-enabled
Real authentication, database/RLS, age/identity verification, payments/payouts, production media moderation, and live AI provider integration are intentionally not faked. Build those as the next milestones; never put secrets in browser code.
